import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class WarehouseManagementSystem {
    public static void main(String[] args) {
        Warehouse warehouse = new Warehouse();
        try (Scanner scanner = new Scanner(System.in)) {
            boolean loop = true;
            do {
                System.out.println("\n*** Warehouse Management System ***");
                System.out.println("1. Add Product");
                System.out.println("2. Create Shipment");
                System.out.println("3. Calculate Total Inventory Cost");
                System.out.println("4. Receive Shipment");
                System.out.println("5. View Inventory");
                System.out.println("6. Quit");
                System.out.print("Select an option: ");

                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1:
                        System.out.print("Enter product name: ");
                        String productName = scanner.nextLine();
                        System.out.print("Enter price: ");
                        double price = Double.parseDouble(scanner.nextLine());
                        System.out.print("Enter quantity: ");
                        int quantity = Integer.parseInt(scanner.nextLine());
                        warehouse.addProduct(productName, price, quantity);
                        break;
                    case 2: 
                        System.out.print("Enter number of products in the shipment: ");
                        int numProductsInShipment = Integer.parseInt(scanner.nextLine());
                        List<Product> shipmentProducts = new ArrayList<>();
                        for (int i = 0; i < numProductsInShipment; i++) {
                            System.out.println("Product " + (i + 1) + ":");
                            System.out.print("  Enter product name: ");
                            String shipmentProductName = scanner.nextLine();
                            System.out.print("  Enter price: ");
                            double shipmentPrice = Double.parseDouble(scanner.nextLine());
                            System.out.print("  Enter quantity: ");
                            int shipmentQuantity = Integer.parseInt(scanner.nextLine());
                            shipmentProducts.add(new Product(shipmentProductName, shipmentPrice, shipmentQuantity));
                        }
                        warehouse.createShipment(shipmentProducts);
                        break;
                    case 3:
                        System.out.println("Total Inventory Cost: " + warehouse.calculateTotalInventoryCost());
                        break;
                    case 4:
                        System.out.print("Enter the shipment ID: ");
                        int shipmentId = Integer.parseInt(scanner.nextLine());
                        warehouse.receiveShipment(shipmentId);
                        break;
                    case 5:
                        warehouse.viewInventory();
                        break;
                    case 6:
                        loop = false;
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                        break;
                }
            } while (loop);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }
}