import java.util.ArrayList;
import java.util.List;


class Product {
    private static int idCounter = 1;

    private int productId;
    private String productName;
    private double price;
    private int quantity;

    public Product(String productName, double price, int quantity) {
        this.productId = idCounter++;
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
    }

    public int getProductId() {
        return productId;
    }

    public double getTotalCost() {
        return this.getPrice() * this.getQuantity();
    }

    public String getProductName() {
        return productName;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void decreaseQuantity(int amount) {
        if (quantity >= amount) {
            quantity -= amount;
            System.out.println("Quantity updated: " + productName + " - New Quantity: " + quantity);
        } else {
            System.out.println("Insufficient quantity in stock for " + productName);
        }
    }

    public void increaseQuantity(int amount) {
        quantity += amount;
        System.out.println("Quantity updated: " + productName + " - New Quantity: " + quantity);
    }

    public double calculateTotalValue() {
        return price * quantity;
    }

    public boolean isRunningLow() {
        return quantity < 10;
    }

    public void displayProductSummary() {
        System.out.println("\nProduct Summary:");
        System.out.println("ID: " + productId);
        System.out.println("Name: " + productName);
        System.out.println("Price: $" + price);
        System.out.println("Quantity: " + quantity);
        System.out.println("Total Value: $" + calculateTotalValue());
        System.out.println("Running Low: " + (isRunningLow() ? "Yes" : "No"));
    }
}

class Shipment {
    private static int idCounter = 1;

    private int shipmentId;
    private List<Product> products;
    private boolean received;

    public Shipment(List<Product> products) {
        this.shipmentId = idCounter++;
        this.products = products;
        this.received = false;
    }

    public int getShipmentId() {
        return shipmentId;
    }

    public List<Product> getProducts() {
        return products;
    }

    public boolean isReceived() {
        return received;
    }

    public void markAsReceived() {
        received = true;
        System.out.println("Shipment marked as received. Shipment ID: " + shipmentId);
    }

    public double calculateTotalShipmentValue() {
        double totalValue = 0;
        for (Product product : products) {
            totalValue += product.calculateTotalValue();
        }
        return totalValue;
    }

    public void displayShipmentSummary() {
        System.out.println("\nShipment Summary:");
        System.out.println("Shipment ID: " + shipmentId);
        System.out.println("Received: " + (received ? "Yes" : "No"));
        System.out.println("Total Shipment Value: $" + calculateTotalShipmentValue());

        System.out.println("\nProducts in Shipment:");
        for (Product product : products) {
            System.out.println("Product ID: " + product.getProductId() +
                    " | Name: " + product.getProductName() +
                    " | Quantity: " + product.getQuantity() +
                    " | Total Value: $" + product.calculateTotalValue());
        }
    }
}

class Warehouse {
    private List<Product> products;
    private List<Shipment> shipments;
    
    public Warehouse() {
        this.products = new ArrayList<>();
        this.shipments = new ArrayList<>();
        
    }

    public double calculateTotalInventoryCost() {
        if (this.products == null) {
            return 0; 
        }

        double totalCost = 0;
        for (Product product : this.products) {
            totalCost += product.getTotalCost();
        }
        return totalCost;
    }

    public void addProduct(String productName, double price, int quantity) {
        Product product = new Product(productName, price, quantity);
        products.add(product);
        System.out.println("Product added to the warehouse: " + product.getProductName());
    }

    public void createShipment(List<Product> products) {
        Shipment shipment = new Shipment(products);
        shipments.add(shipment);
        System.out.println("Shipment created. Shipment ID: " + shipment.getShipmentId());
    }

    

    public void receiveShipment(int shipmentId) {
        Shipment shipment = findShipmentById(shipmentId);
        if (shipment != null && !shipment.isReceived()) {
            for (Product product : shipment.getProducts()) {
                Product existingProduct = findProductById(product.getProductId());
                if (existingProduct != null) {
                    existingProduct.increaseQuantity(product.getQuantity());
                } else {
                    products.add(product);
                }
            }
            shipment.markAsReceived();
            System.out.println("Shipment received and inventory updated.");
        } else if (shipment == null) {
            System.out.println("Shipment with ID " + shipmentId + " not found.");
        } else {
            System.out.println("Shipment with ID " + shipmentId + " has already been received.");
        }
    }

    public void viewInventory() {
        System.out.println("\nCurrent Inventory:");
        for (Product product : products) {
            System.out.println("ID: " + product.getProductId() +
                    " | Name: " + product.getProductName() +
                    " | Quantity: " + product.getQuantity() +
                    " | Price: $" + product.getPrice());
        }
    }

    private Product findProductById(int productId) {
        for (Product product : products) {
            if (product.getProductId() == productId) {
                return product;
            }
        }
        return null;
    }

    private Shipment findShipmentById(int shipmentId) {
        for (Shipment shipment : shipments) {
            if (shipment.getShipmentId() == shipmentId) {
                return shipment;
            }
        }
        return null;
    }
}
